#ifndef PLAYER_H
#define PLAYER_H

class player{
    private: //so where do we declare them?
        int basedamage;
        int weapondamage;
        int health;
        int maxhealth;
        int currentxp;
        int xpneeded; //wait, which variable? the one thats on this line - ill fix quickly
        int money;
        int maxmoney;
        int majik;
        int maxmajik;
        int playerlevel = 1;

    public:
        player(int maxhealth, int maxmajik);
        ~player(){};
        int getmoney();
        int gethealth();
        int getdamage();
        int getmajik();
        int getcurrentxp();
        int getmaxhealth();
        int getmaxmajik();
        int getxpneeded();
        int getplayerlevel();

};
#endif
